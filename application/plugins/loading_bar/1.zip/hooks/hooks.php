<?php
$hook['tech5s_before_footer'][] = array( 
  'class'    => 'LoadingBar',
  'function' => 'insertScript',
  'filename' => 'LoadingBar.php',
  'filepath' => 'plugins/loading_bar',
);
